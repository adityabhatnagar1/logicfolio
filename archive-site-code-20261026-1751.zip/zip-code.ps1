$root  = $PSScriptRoot
$stamp = Get-Date -Format 'yyyyMMdd-HHmm'
$out   = Join-Path $root "archive-site-code-$stamp.zip"
$stage = Join-Path $env:TEMP "zipstage-$stamp"

# Bloat to skip
$skipDirs  = 'node_modules','.astro','dist','.git','.vscode','.idea','fonts'
$skipFiles = 'package-lock.json','*.zip','*.log','.DS_Store'

New-Item -ItemType Directory -Path $stage -Force | Out-Null

# robocopy keeps structure and applies the excludes (exit codes < 8 are success)
robocopy $root $stage /E /XD $skipDirs /XF $skipFiles /NFL /NDL /NJH /NJS /NP | Out-Null
if ($LASTEXITCODE -ge 8) { throw "robocopy failed ($LASTEXITCODE)" }

if (Test-Path $out) { Remove-Item $out -Force }
Add-Type -AssemblyName System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::CreateFromDirectory($stage, $out)

Remove-Item $stage -Recurse -Force
$mb = '{0:N2}' -f ((Get-Item $out).Length / 1MB)
Write-Host "Done: $out ($mb MB)"