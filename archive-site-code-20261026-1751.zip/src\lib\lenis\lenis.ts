const version = "1.3.26";
import { Animate } from "./animate";
import { Dimensions } from "./dimensions";
import { Emitter } from "./emitter";
import { clamp, modulo } from "./maths";
import type {
  LenisEvent,
  LenisOptions,
  ScrollCallback,
  Scrolling,
  ScrollToOptions,
  UserData,
  VirtualScrollCallback,
  VirtualScrollData,
} from "./types";
import { VirtualScroll } from "./virtual-scroll";

// Technical explanation
// - listen to 'wheel' events
// - prevent 'wheel' event to prevent scroll
// - normalize wheel delta
// - add delta to targetScroll
// - animate scroll to targetScroll (smooth context)
// - if animation is not running, listen to 'scroll' events (native context)

type OptionalPick<T, F extends keyof T> = Omit<T, F> & Partial<Pick<T, F>>;

const defaultEasing = (t: number) => Math.min(1, 1.001 - 2 ** (-10 * t));

export class Lenis {
  private _isScrolling: Scrolling = false; // true when scroll is animating
  private _isStopped = false; // true if user should not be able to scroll - enable/disable programmatically
  private _isLocked = false; // same as isStopped but enabled/disabled when scroll reaches target
  private _preventNextNativeScrollEvent = false;
  private _resetVelocityTimeout: ReturnType<typeof setTimeout> | null = null;
  private _rafId: number | null = null;
  private _isDraggingSelection = false; // true while a touch is dragging an iOS selection handle
  // `.matches` is read at scroll time so preference changes apply live, no listener needed
  private readonly reducedMotionMediaQuery = window.matchMedia(
    "(prefers-reduced-motion: reduce)",
  );

  /**
   * Whether or not the user is touching the screen
   */
  isTouching?: boolean;
  /**
   * Whether or not the device is running iOS
   */
  isIos: boolean;
  /**
   * The time in ms since the lenis instance was created
   */
  time = 0;
  /**
   * User data that will be forwarded through the scroll event
   *
   * @example
   * lenis.scrollTo(100, {
   *   userData: {
   *     foo: 'bar'
   *   }
   * })
   */
  userData: UserData = {};
  /**
   * The last velocity of the scroll
   */
  lastVelocity = 0;
  /**
   * The current velocity of the scroll
   */
  velocity = 0;
  /**
   * The direction of the scroll
   */
  direction: 1 | -1 | 0 = 0;
  /**
   * The options passed to the lenis instance
   */
  options: OptionalPick<
    Required<LenisOptions>,
    | "duration"
    | "easing"
    | "prevent"
    | "virtualScroll"
    | "__experimental__naiveDimensions"
  >;
  /**
   * The target scroll value
   */
  targetScroll: number;
  /**
   * The animated scroll value
   */
  animatedScroll: number;

  // These are instanciated here as they don't need information from the options
  private readonly animate = new Animate();
  private readonly emitter = new Emitter();
  // These are instanciated in the constructor as they need information from the options
  readonly dimensions: Dimensions; // This is not private because it's used in the Snap class
  private readonly virtualScroll: VirtualScroll;

  constructor({
    wrapper = window,
    content = document.documentElement,
    eventsTarget = wrapper,
    smoothWheel = true,
    syncTouch = false,
    syncTouchLerp = 0.075,
    touchInertiaExponent = 1.7,
    duration, // in seconds
    easing,
    lerp = 0.1,
    infinite = false,
    orientation = "vertical", // vertical, horizontal
    gestureOrientation = orientation === "horizontal" ? "both" : "vertical", // vertical, horizontal, both
    touchMultiplier = 1,
    wheelMultiplier = 1,
    autoResize = true,
    prevent,
    virtualScroll,
    overscroll = true,
    autoRaf = false,
    anchors = false,
    autoToggle = false, // https://caniuse.com/?search=transition-behavior
    allowNestedScroll = false,
    __experimental__naiveDimensions = false,
    naiveDimensions = __experimental__naiveDimensions,
    stopInertiaOnNavigate = false,
    respectReducedMotion = true,
  }: LenisOptions = {}) {
    // Set version (deprecated)
    window.lenisVersion = version;

    if (!window.lenis) {
      window.lenis = {};
    }

    window.lenis.version = version;

    if (orientation === "horizontal") {
      window.lenis.horizontal = true;
    }

    if (syncTouch === true) {
      window.lenis.touch = true;
    }

    this.isIos = /(iPad|iPhone|iPod)/g.test(navigator.userAgent);

    // Check if wrapper is <html>, fallback to window
    if (!wrapper || wrapper === document.documentElement) {
      wrapper = window;
    }

    // flip to easing/time based animation if at least one of them is provided
    if (typeof duration === "number" && typeof easing !== "function") {
      easing = defaultEasing;
    } else if (typeof easing === "function" && typeof duration !== "number") {
      duration = 1;
    }

    // Setup options
    this.options = {
      wrapper,
      content,
      eventsTarget,
      smoothWheel,
      syncTouch,
      syncTouchLerp,
      touchInertiaExponent,
      duration,
      easing,
      lerp,
      infinite,
      gestureOrientation,
      orientation,
      touchMultiplier,
      wheelMultiplier,
      autoResize,
      prevent,
      virtualScroll,
      overscroll,
      autoRaf,
      anchors,
      autoToggle,
      allowNestedScroll,
      naiveDimensions,
      stopInertiaOnNavigate,
      respectReducedMotion,
    };

    // Setup dimensions instance
    this.dimensions = new Dimensions(wrapper, content, { autoResize });

    // Setup class name
    this.updateClassName();

    // Set the initial scroll value for all scroll information
    this.targetScroll = this.animatedScroll = this.actualScroll;

    // Add event listeners
    this.options.wrapper.addEventListener("scroll", this.onNativeScroll);

    this.options.wrapper.addEventListener("scrollend", this.onScrollEnd, {
      capture: true,
    });

    if (this.options.anchors || this.options.stopInertiaOnNavigate) {
      this.options.wrapper.addEventListener(
        "click",
        this.onClick as EventListener,
      );
    }

    this.options.wrapper.addEventListener(
      "pointerdown",
      this.onPointerDown as EventListener,
    );

    // Setup virtual scroll instance
    this.virtualScroll = new VirtualScroll(eventsTarget as HTMLElement, {
      touchMultiplier,
      wheelMultiplier,
    });
    this.virtualScroll.on("scroll", this.onVirtualScroll);

    if (this.options.autoToggle) {
      this.checkOverflow();
      this.rootElement.addEventListener("transitionend", this.onTransitionEnd);
    }

    if (this.options.autoRaf) {
      this._rafId = requestAnimationFrame(this.raf);
    }
  }

  /**
   * Destroy the lenis instance, remove all event listeners and clean up the class name
   */
  destroy() {
    this.emitter.destroy();

    this.options.wrapper.removeEventListener("scroll", this.onNativeScroll);

    this.options.wrapper.removeEventListener("scrollend", this.onScrollEnd, {
      capture: true,
    });

    this.options.wrapper.removeEventListener(
      "pointerdown",
      this.onPointerDown as EventListener,
    );

    if (this.options.anchors || this.options.stopInertiaOnNavigate) {
      this.options.wrapper.removeEventListener(
        "click",
        this.onClick as EventListener,
      );
    }

    this.virtualScroll.destroy();
    this.dimensions.destroy();

    this.cleanUpClassName();

    if (this._rafId) {
      cancelAnimationFrame(this._rafId);
    }
  }

  /**
   * Add an event listener for the given event and callback
   *
   * @param event Event name
   * @param callback Callback function
   * @returns Unsubscribe function
   */
  on(event: "scroll", callback: ScrollCallback): () => void;
  on(event: "virtual-scroll", callback: VirtualScrollCallback): () => void;
  on(event: LenisEvent, callback: ScrollCallback | VirtualScrollCallback) {
    return this.emitter.on(event, callback as (...args: unknown[]) => void);
  }

  /**
   * Remove an event listener for the given event and callback
   *
   * @param event Event name
   * @param callback Callback function
   */
  off(event: "scroll", callback: ScrollCallback): void;
  off(event: "virtual-scroll", callback: VirtualScrollCallback): void;
  off(event: LenisEvent, callback: ScrollCallback | VirtualScrollCallback) {
    return this.emitter.off(event, callback as (...args: unknown[]) => void);
  }

  private onScrollEnd = (e: Event | CustomEvent) => {
    if (!(e instanceof CustomEvent)) {
      if (this.isScrolling === "smooth" || this.isScrolling === false) {
        e.stopPropagation();
      }
    }
  };

  private dispatchScrollendEvent = () => {
    this.options.wrapper.dispatchEvent(
      new CustomEvent("scrollend", {
        bubbles: this.options.wrapper === window,
        // cancelable: false,
        detail: {
          lenisScrollEnd: true,
        },
      }),
    );
  };

  get overflow() {
    const property = this.isHorizontal ? "overflow-x" : "overflow-y";
    return getComputedStyle(this.rootElement)[
      property as keyof CSSStyleDeclaration
    ] as string;
  }

  private checkOverflow() {
    if (["hidden", "clip"].includes(this.overflow)) {
      this.internalStop();
    } else {
      this.internalStart();
    }
  }

  private onTransitionEnd = (event: TransitionEvent) => {
    if (
      event.propertyName?.includes("overflow") &&
      event.target === this.rootElement
    ) {
      this.checkOverflow();
    }
  };

  private setScroll(scroll: number) {
    // behavior: 'instant' bypasses the scroll-behavior CSS property

    if (this.isHorizontal) {
      this.options.wrapper.scrollTo({ left: scroll, behavior: "instant" });
    } else {
      this.options.wrapper.scrollTo({ top: scroll, behavior: "instant" });
    }
  }

  private onClick = (event: PointerEvent | MouseEvent) => {
    const path = event.composedPath();

    // filter anchor elements (elements with a valid href attribute)
    const linkElements = path.filter(
      (node) => node instanceof HTMLAnchorElement && node.href,
    ) as HTMLAnchorElement[];
    const linkElementsUrls = linkElements.map(
      (element) => new URL(element.href),
    );

    const currentUrl = new URL(window.location.href);

    if (this.options.anchors) {
      const anchorElementUrl = linkElementsUrls.find(
        (targetUrl) =>
          currentUrl.host === targetUrl.host &&
          currentUrl.pathname === targetUrl.pathname &&
          targetUrl.hash,
      );

      if (anchorElementUrl) {
        const options =
          typeof this.options.anchors === "object" && this.options.anchors
            ? this.options.anchors
            : undefined;

        // hash is URL-encoded (e.g. `#footnote-%E2%80%A0`); decode so it
        // matches the raw HTML id in scrollTo's getElementById
        const target = decodeURIComponent(anchorElementUrl.hash);

        this.scrollTo(target, options);
        return;
      }
    }

    if (this.options.stopInertiaOnNavigate) {
      const hasPageLinkElementUrl = linkElementsUrls.some(
        (targetUrl) =>
          currentUrl.host === targetUrl.host &&
          currentUrl.pathname !== targetUrl.pathname,
      );

      if (hasPageLinkElementUrl) {
        this.reset();
        return;
      }
    }
  };

  private onPointerDown = (event: PointerEvent | MouseEvent) => {
    if (event.button === 1) {
      this.reset();
    }
  };

  // iOS renders text-selection handles at the start and end points of the
  // selection. A touch starting within a handle-sized radius of either point is
  // the user grabbing a handle, not scrolling.
  private isTouchOnSelectionHandle(event: TouchEvent) {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || selection.rangeCount === 0)
      return false;

    const touch = event.targetTouches[0] ?? event.changedTouches[0];
    if (!touch) return false;

    const rects = selection.getRangeAt(0).getClientRects();
    if (rects.length === 0) return false;

    const first = rects[0]!;
    const last = rects[rects.length - 1]!;
    const HANDLE_RADIUS = 40; // px — handles are large, finger-sized touch targets

    const nearStart =
      Math.hypot(touch.clientX - first.left, touch.clientY - first.top) <=
      HANDLE_RADIUS;
    const nearEnd =
      Math.hypot(touch.clientX - last.right, touch.clientY - last.bottom) <=
      HANDLE_RADIUS;

    return nearStart || nearEnd;
  }

  private onVirtualScroll = (data: VirtualScrollData) => {
    if (
      typeof this.options.virtualScroll === "function" &&
      this.options.virtualScroll(data) === false
    )
      return;

    const { deltaX, deltaY, event } = data;

    this.emitter.emit("virtual-scroll", { deltaX, deltaY, event });

    // keep zoom feature
    if (event.ctrlKey) return;
    // @ts-expect-error
    if (event.lenisStopPropagation) return;

    const isTouch = event.type.includes("touch");
    const isWheel = event.type.includes("wheel");

    // If the touch grabbed an iOS text-selection handle, let the OS adjust the
    // selection instead of scrolling. Latched on touchstart, held until touchend.
    if (isTouch && this.isIos) {
      if (event.type === "touchstart") {
        this._isDraggingSelection = this.isTouchOnSelectionHandle(
          event as TouchEvent,
        );
      }
      if (this._isDraggingSelection) {
        if (event.type === "touchend") this._isDraggingSelection = false;
        return;
      }
    }

    this.isTouching = event.type === "touchstart" || event.type === "touchmove";

    const isClickOrTap = deltaX === 0 && deltaY === 0;

    const isTapToStop =
      this.options.syncTouch &&
      isTouch &&
      event.type === "touchstart" &&
      isClickOrTap &&
      !this.isStopped &&
      !this.isLocked;

    if (isTapToStop) {
      this.reset();
      return;
    }

    // const isPullToRefresh =
    //   this.options.gestureOrientation === 'vertical' &&
    //   this.scroll === 0 &&
    //   !this.options.infinite &&
    //   deltaY <= 5 // touch pull to refresh, not reliable yet

    // most likely a touchpad gesture, this keep prev/next page navigation working
    const isUnknownGesture =
      (this.options.gestureOrientation === "vertical" && deltaY === 0) ||
      (this.options.gestureOrientation === "horizontal" && deltaX === 0);

    if (isClickOrTap || isUnknownGesture) {
      return;
    }

    // catch if scrolling on nested scroll elements
    let composedPath = event.composedPath();
    composedPath = composedPath.slice(
      0,
      composedPath.indexOf(this.rootElement),
    ); // remove parents elements

    const prevent = this.options.prevent;

    const gestureOrientation =
      Math.abs(deltaX) >= Math.abs(deltaY) ? "horizontal" : "vertical";

    if (
      composedPath.find(
        (node) =>
          node instanceof HTMLElement &&
          ((typeof prevent === "function" && prevent?.(node)) ||
            node.hasAttribute?.("data-lenis-prevent") ||
            (gestureOrientation === "vertical" &&
              node.hasAttribute?.("data-lenis-prevent-vertical")) ||
            (gestureOrientation === "horizontal" &&
              node.hasAttribute?.("data-lenis-prevent-horizontal")) ||
            (isTouch && node.hasAttribute?.("data-lenis-prevent-touch")) ||
            (isWheel && node.hasAttribute?.("data-lenis-prevent-wheel")) ||
            (this.options.allowNestedScroll &&
              this.hasNestedScroll(node, {
                deltaX,
                deltaY,
              }))),
      )
    )
      return;

    if (this.isStopped || this.isLocked) {
      if (event.cancelable) {
        event.preventDefault(); // this will stop forwarding the event to the parent, this is problematic
      }
      return;
    }

    const isSmooth =
      (this.options.syncTouch && isTouch) ||
      (this.options.smoothWheel && isWheel);

    if (!isSmooth) {
      this.isScrolling = "native";
      this.animate.stop();
      // @ts-expect-error
      event.lenisStopPropagation = true;
      return;
    }

    let delta = deltaY;
    if (this.options.gestureOrientation === "both") {
      delta = Math.abs(deltaY) > Math.abs(deltaX) ? deltaY : deltaX;
    } else if (this.options.gestureOrientation === "horizontal") {
      delta = deltaX;
    }

    if (
      !this.options.overscroll ||
      this.options.infinite ||
      (this.options.wrapper !== window &&
        this.limit > 0 &&
        ((this.animatedScroll > 0 && this.animatedScroll < this.limit) ||
          (this.animatedScroll === 0 && deltaY > 0) ||
          (this.animatedScroll === this.limit && deltaY < 0)))
    ) {
      // @ts-expect-error
      event.lenisStopPropagation = true;
      // event.stopPropagation()
    }

    if (event.cancelable) {
      event.preventDefault();
    }

    const isSyncTouch = isTouch && this.options.syncTouch;
    const isTouchEnd = isTouch && event.type === "touchend";

    const hasTouchInertia = isTouchEnd;

    if (hasTouchInertia) {
      delta =
        Math.sign(delta) *
        Math.abs(this.velocity) ** this.options.touchInertiaExponent;
    }

    this.scrollTo(this.targetScroll + delta, {
      programmatic: false,
      ...(isSyncTouch
        ? {
            lerp: hasTouchInertia ? this.options.syncTouchLerp : 1,
          }
        : {
            lerp: this.options.lerp,
            duration: this.options.duration,
            easing: this.options.easing,
          }),
    });
  };

  /**
   * Force lenis to recalculate the dimensions
   */
  resize() {
    this.dimensions.resize();
    this.animatedScroll = this.targetScroll = this.actualScroll;
    this.emit();
  }

  private emit() {
    this.emitter.emit("scroll", this);
  }

  private onNativeScroll = () => {
    if (this._resetVelocityTimeout !== null) {
      clearTimeout(this._resetVelocityTimeout);
      this._resetVelocityTimeout = null;
    }

    if (this._preventNextNativeScrollEvent) {
      this._preventNextNativeScrollEvent = false;
      return;
    }

    if (this.isScrolling === false || this.isScrolling === "native") {
      const lastScroll = this.animatedScroll;
      this.animatedScroll = this.targetScroll = this.actualScroll;
      this.lastVelocity = this.velocity;
      this.velocity = this.animatedScroll - lastScroll;
      this.direction = Math.sign(
        this.animatedScroll - lastScroll,
      ) as Lenis["direction"];

      if (!this.isStopped) {
        this.isScrolling = "native";
      }

      this.emit();

      if (this.velocity !== 0) {
        this._resetVelocityTimeout = setTimeout(() => {
          this.lastVelocity = this.velocity;
          this.velocity = 0;
          this.isScrolling = false;
          this.emit();
        }, 400);
      }
    }
  };

  private reset() {
    this.isLocked = false;
    this.isScrolling = false;
    this.animatedScroll = this.targetScroll = this.actualScroll;
    this.lastVelocity = this.velocity = 0;
    this.animate.stop();
  }

  /**
   * Start lenis scroll after it has been stopped
   */
  start() {
    if (!this.isStopped) return;

    if (this.options.autoToggle) {
      this.rootElement.style.removeProperty("overflow");
      return;
    }

    this.internalStart();
  }

  private internalStart() {
    if (!this.isStopped) return;

    this.reset();
    this.isStopped = false;
    this.emit();
  }

  /**
   * Stop lenis scroll
   */
  stop() {
    if (this.isStopped) return;

    if (this.options.autoToggle) {
      this.rootElement.style.setProperty("overflow", "clip");
      return;
    }

    this.internalStop();
  }

  private internalStop() {
    if (this.isStopped) return;

    this.reset();
    this.isStopped = true;
    this.emit();
  }

  /**
   * RequestAnimationFrame for lenis
   *
   * @param time The time in ms from an external clock like `requestAnimationFrame` or Tempus
   */
  raf = (time: number) => {
    const deltaTime = time - (this.time || time);
    this.time = time;

    this.animate.advance(deltaTime * 0.001);

    if (this.options.autoRaf) {
      this._rafId = requestAnimationFrame(this.raf);
    }
  };

  /**
   * Scroll to a target value
   *
   * @param target The target value to scroll to
   * @param options The options for the scroll
   *
   * @example
   * lenis.scrollTo(100, {
   *   offset: 100,
   *   duration: 1,
   *   easing: (t) => 1 - Math.cos((t * Math.PI) / 2),
   *   lerp: 0.1,
   *   onStart: () => {
   *     console.log('onStart')
   *   },
   *   onComplete: () => {
   *     console.log('onComplete')
   *   },
   * })
   */
  scrollTo(
    _target: number | string | HTMLElement,
    {
      offset = 0,
      immediate = false,
      lock = false,
      programmatic = true, // called from outside of the class
      lerp = programmatic ? this.options.lerp : undefined,
      duration = programmatic ? this.options.duration : undefined,
      easing = programmatic ? this.options.easing : undefined,
      onStart,
      onComplete,
      force = false, // scroll even if stopped
      userData,
    }: ScrollToOptions = {},
  ) {
    if (this.prefersReducedMotion) {
      if (programmatic) {
        // jump cut instead of animation
        immediate = true;
      } else {
        // 1:1 input tracking, same mechanism as syncTouch finger tracking
        lerp = 1;
        duration = undefined;
        easing = undefined;
      }
    }

    if ((this.isStopped || this.isLocked) && !force) return;

    let target: number | string | HTMLElement = _target;
    let adjustedOffset = offset;

    // keywords
    if (
      typeof target === "string" &&
      ["top", "left", "start", "#"].includes(target)
    ) {
      target = 0;
    } else if (
      typeof target === "string" &&
      ["bottom", "right", "end"].includes(target)
    ) {
      target = this.limit;
    } else {
      let node: Element | null = null;

      if (typeof target === "string") {
        // getElementById accepts any valid HTML id (e.g. `#footnote-†`),
        // querySelector would reject it as an invalid CSS selector
        node = target.startsWith("#")
          ? document.getElementById(target.slice(1))
          : document.querySelector(target);

        if (!node) {
          if (target === "#top") {
            target = 0;
          } else {
            console.warn("Lenis: Target not found", target);
          }
        }
      } else if (target instanceof HTMLElement && target?.nodeType) {
        // Node element
        node = target;
      }

      if (node) {
        if (this.options.wrapper !== window) {
          // nested scroll offset correction
          const wrapperRect = this.rootElement.getBoundingClientRect();
          adjustedOffset -= this.isHorizontal
            ? wrapperRect.left
            : wrapperRect.top;
        }

        const rect = node.getBoundingClientRect();

        // Account for scroll-margin CSS property on the target element
        const targetStyle = getComputedStyle(node);
        const scrollMargin = this.isHorizontal
          ? Number.parseFloat(targetStyle.scrollMarginLeft)
          : Number.parseFloat(targetStyle.scrollMarginTop);

        // Account for scroll-padding CSS property on the scroll container
        const containerStyle = getComputedStyle(this.rootElement);
        const scrollPadding = this.isHorizontal
          ? Number.parseFloat(containerStyle.scrollPaddingLeft)
          : Number.parseFloat(containerStyle.scrollPaddingTop);

        target =
          (this.isHorizontal ? rect.left : rect.top) +
          this.animatedScroll -
          (Number.isNaN(scrollMargin) ? 0 : scrollMargin) -
          (Number.isNaN(scrollPadding) ? 0 : scrollPadding);
      }
    }

    if (typeof target !== "number") return;

    target += adjustedOffset;
    // target = Math.round(target)

    if (this.options.infinite) {
      if (programmatic) {
        this.targetScroll = this.animatedScroll = this.scroll;

        const distance = target - this.animatedScroll;

        if (distance > this.limit / 2) {
          target -= this.limit;
        } else if (distance < -this.limit / 2) {
          target += this.limit;
        }
      }
    } else {
      target = clamp(0, target, this.limit);
    }

    if (target === this.targetScroll) {
      onStart?.(this);
      onComplete?.(this);
      return;
    }

    this.userData = userData ?? {};

    if (immediate) {
      this.animatedScroll = this.targetScroll = target;
      this.setScroll(this.scroll);
      this.reset();
      this.preventNextNativeScrollEvent();
      this.emit();
      onComplete?.(this);
      this.userData = {};

      requestAnimationFrame(() => {
        this.dispatchScrollendEvent();
      });
      return;
    }

    if (!programmatic) {
      this.targetScroll = target;
    }

    // flip to easing/time based animation if at least one of them is provided
    if (typeof duration === "number" && typeof easing !== "function") {
      easing = defaultEasing;
    } else if (typeof easing === "function" && typeof duration !== "number") {
      duration = 1;
    }

    this.animate.fromTo(this.animatedScroll, target, {
      duration,
      easing,
      lerp,
      onStart: () => {
        // started
        if (lock) this.isLocked = true;
        this.isScrolling = "smooth";
        onStart?.(this);
      },
      onUpdate: (value: number, completed: boolean) => {
        this.isScrolling = "smooth";

        // updated
        this.lastVelocity = this.velocity;
        this.velocity = value - this.animatedScroll;
        this.direction = Math.sign(this.velocity) as Lenis["direction"];

        this.animatedScroll = value;
        this.setScroll(this.scroll);

        if (programmatic) {
          // wheel during programmatic should stop it
          this.targetScroll = value;
        }

        if (!completed) this.emit();

        if (completed) {
          this.reset();
          this.emit();
          onComplete?.(this);
          this.userData = {};

          requestAnimationFrame(() => {
            this.dispatchScrollendEvent();
          });

          // avoid emitting event twice
          this.preventNextNativeScrollEvent();
        }
      },
    });
  }

  private preventNextNativeScrollEvent() {
    this._preventNextNativeScrollEvent = true;

    requestAnimationFrame(() => {
      this._preventNextNativeScrollEvent = false;
    });
  }

  private hasNestedScroll(
    node: HTMLElement,
    { deltaX, deltaY }: { deltaX: number; deltaY: number },
  ) {
    const time = Date.now();

    // @ts-expect-error - _lenis is a custom cache property
    if (!node._lenis) node._lenis = {};
    // @ts-expect-error
    const cache = node._lenis;

    let hasOverflowX: boolean | undefined;
    let hasOverflowY: boolean | undefined;
    let isScrollableX: boolean | undefined;
    let isScrollableY: boolean | undefined;
    let hasOverscrollBehaviorX: boolean | undefined;
    let hasOverscrollBehaviorY: boolean | undefined;
    let scrollWidth: number;
    let scrollHeight: number;
    let clientWidth: number;
    let clientHeight: number;

    if (time - (cache.time ?? 0) > 2000) {
      cache.time = Date.now();

      const computedStyle = window.getComputedStyle(node);
      cache.computedStyle = computedStyle;

      hasOverflowX = ["auto", "overlay", "scroll"].includes(
        computedStyle.overflowX,
      );
      hasOverflowY = ["auto", "overlay", "scroll"].includes(
        computedStyle.overflowY,
      );

      hasOverscrollBehaviorX = ["auto"].includes(
        computedStyle.overscrollBehaviorX,
      );
      hasOverscrollBehaviorY = ["auto"].includes(
        computedStyle.overscrollBehaviorY,
      );

      cache.hasOverflowX = hasOverflowX;
      cache.hasOverflowY = hasOverflowY;

      if (!(hasOverflowX || hasOverflowY)) return false; // if no overflow, it's not scrollable no matter what, early return saves some computations

      scrollWidth = node.scrollWidth;
      scrollHeight = node.scrollHeight;

      clientWidth = node.clientWidth;
      clientHeight = node.clientHeight;

      isScrollableX = scrollWidth > clientWidth;
      isScrollableY = scrollHeight > clientHeight;

      cache.isScrollableX = isScrollableX;
      cache.isScrollableY = isScrollableY;
      cache.scrollWidth = scrollWidth;
      cache.scrollHeight = scrollHeight;
      cache.clientWidth = clientWidth;
      cache.clientHeight = clientHeight;
      cache.hasOverscrollBehaviorX = hasOverscrollBehaviorX;
      cache.hasOverscrollBehaviorY = hasOverscrollBehaviorY;
    } else {
      isScrollableX = cache.isScrollableX;
      isScrollableY = cache.isScrollableY;
      hasOverflowX = cache.hasOverflowX;
      hasOverflowY = cache.hasOverflowY;
      scrollWidth = cache.scrollWidth;
      scrollHeight = cache.scrollHeight;
      clientWidth = cache.clientWidth;
      clientHeight = cache.clientHeight;
      hasOverscrollBehaviorX = cache.hasOverscrollBehaviorX;
      hasOverscrollBehaviorY = cache.hasOverscrollBehaviorY;
    }

    if (!((hasOverflowX && isScrollableX) || (hasOverflowY && isScrollableY))) {
      return false;
    }

    const orientation =
      Math.abs(deltaX) >= Math.abs(deltaY) ? "horizontal" : "vertical";

    let scroll: number | undefined;
    let maxScroll: number | undefined;
    let delta: number | undefined;
    let hasOverflow: boolean | undefined;
    let isScrollable: boolean | undefined;
    let hasOverscrollBehavior: boolean | undefined;

    if (orientation === "horizontal") {
      scroll = Math.round(node.scrollLeft);
      maxScroll = scrollWidth - clientWidth;
      delta = deltaX;

      hasOverflow = hasOverflowX;
      isScrollable = isScrollableX;
      hasOverscrollBehavior = hasOverscrollBehaviorX;
    } else if (orientation === "vertical") {
      scroll = Math.round(node.scrollTop);
      maxScroll = scrollHeight - clientHeight;
      delta = deltaY;

      hasOverflow = hasOverflowY;
      isScrollable = isScrollableY;
      hasOverscrollBehavior = hasOverscrollBehaviorY;
    } else {
      return false;
    }

    if (!hasOverscrollBehavior && (scroll >= maxScroll || scroll <= 0)) {
      return true;
    }

    const willScroll = delta > 0 ? scroll < maxScroll : scroll > 0;

    return willScroll && hasOverflow && isScrollable;
  }

  /**
   * The root element on which lenis is instanced
   */
  get rootElement() {
    return (
      this.options.wrapper === window
        ? document.documentElement
        : this.options.wrapper
    ) as HTMLElement;
  }

  /**
   * The limit which is the maximum scroll value
   */
  get limit() {
    if (this.options.naiveDimensions) {
      if (this.isHorizontal) {
        return this.rootElement.scrollWidth - this.rootElement.clientWidth;
      }
      return this.rootElement.scrollHeight - this.rootElement.clientHeight;
    }
    return this.dimensions.limit[this.isHorizontal ? "x" : "y"];
  }

  /**
   * Whether or not the scroll is horizontal
   */
  get isHorizontal() {
    return this.options.orientation === "horizontal";
  }

  /**
   * The actual scroll value
   */
  get actualScroll() {
    // value browser takes into account
    // it has to be this way because of DOCTYPE declaration
    const wrapper = this.options.wrapper as Window | HTMLElement;

    return this.isHorizontal
      ? ((wrapper as Window).scrollX ?? (wrapper as HTMLElement).scrollLeft)
      : ((wrapper as Window).scrollY ?? (wrapper as HTMLElement).scrollTop);
  }

  /**
   * The current scroll value
   */
  get scroll() {
    return this.options.infinite
      ? modulo(this.animatedScroll, this.limit)
      : this.animatedScroll;
  }

  /**
   * The progress of the scroll relative to the limit
   */
  get progress() {
    // avoid progress to be NaN
    return this.limit === 0 ? 1 : this.scroll / this.limit;
  }

  /**
   * Current scroll state
   */
  get isScrolling() {
    return this._isScrolling;
  }

  private set isScrolling(value: Scrolling) {
    if (this._isScrolling !== value) {
      this._isScrolling = value;
      this.updateClassName();
    }
  }

  /**
   * Check if lenis is stopped
   */
  get isStopped() {
    return this._isStopped;
  }

  private set isStopped(value: boolean) {
    if (this._isStopped !== value) {
      this._isStopped = value;
      this.updateClassName();
    }
  }

  /**
   * Check if lenis is locked
   */
  get isLocked() {
    return this._isLocked;
  }

  private set isLocked(value: boolean) {
    if (this._isLocked !== value) {
      this._isLocked = value;
      this.updateClassName();
    }
  }

  /**
   * Check if lenis is smooth scrolling
   */
  get isSmooth() {
    return this.isScrolling === "smooth";
  }

  /**
   * Whether the user prefers reduced motion and lenis is honoring it (see `respectReducedMotion` option)
   */
  get prefersReducedMotion() {
    return (
      this.options.respectReducedMotion && this.reducedMotionMediaQuery.matches
    );
  }

  /**
   * The class name applied to the wrapper element
   */
  get className() {
    let className = "lenis";
    if (this.options.autoToggle) className += " lenis-autoToggle";
    if (this.isStopped) className += " lenis-stopped";
    if (this.isLocked) className += " lenis-locked";
    if (this.isScrolling) className += " lenis-scrolling";
    if (this.isScrolling === "smooth") className += " lenis-smooth";
    return className;
  }

  private updateClassName() {
    this.cleanUpClassName();

    this.className.split(" ").forEach((className) => {
      this.rootElement.classList.add(className);
    });
  }

  private cleanUpClassName() {
    for (const className of Array.from(this.rootElement.classList)) {
      if (className === "lenis" || className.startsWith("lenis-")) {
        this.rootElement.classList.remove(className);
      }
    }
  }
}
