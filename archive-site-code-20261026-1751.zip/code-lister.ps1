$root = $PSScriptRoot
$out  = Join-Path $root 'PROJECT_DUMP.md'

# ---- config ----
$skipDirs  = 'node_modules','.astro','dist','.git','.vscode','.idea','fonts'
$skipFiles = 'package-lock.json','PROJECT_DUMP.md'
$textExt   = '.astro','.ts','.js','.mjs','.cjs','.css','.json','.md','.v','.sv','.svh','.vh',
             '.svg','.yml','.yaml','.html','.txt','.gitignore'
$maxBytes  = 400KB

$lang = @{
  '.astro'='astro'; '.ts'='ts'; '.js'='js'; '.mjs'='js'; '.cjs'='js'; '.css'='css'
  '.json'='json'; '.md'='md'; '.v'='verilog'; '.sv'='systemverilog'; '.svh'='systemverilog'
  '.vh'='verilog'; '.svg'='xml'; '.yml'='yaml'; '.yaml'='yaml'; '.html'='html'
  '.txt'=''; '.gitignore'=''
}

# ---- collect files ----
$files = Get-ChildItem $root -Recurse -File -Force | Where-Object {
  $rel   = $_.FullName.Substring($root.Length + 1)
  $parts = $rel -split '[\\/]'
  $dirs  = if ($parts.Count -gt 1) { $parts[0..($parts.Count - 2)] } else { @() }
  -not ($dirs | Where-Object { $skipDirs -contains $_ }) -and
  ($skipFiles -notcontains $_.Name) -and
  ($textExt -contains $_.Extension.ToLower()) -and
  ($_.Length -le $maxBytes)
} | Sort-Object { $_.FullName.Substring($root.Length + 1).Replace('\','/') }

$fileSet = New-Object 'System.Collections.Generic.HashSet[string]'
$dirSet  = New-Object 'System.Collections.Generic.HashSet[string]'
foreach ($f in $files) {
  [void]$fileSet.Add($f.FullName)
  $d = $f.DirectoryName
  while ($d.Length -gt $root.Length) { [void]$dirSet.Add($d); $d = Split-Path $d -Parent }
}

$V = [string][char]0x2502   # │
$T = [string][char]0x251C   # ├
$L = [string][char]0x2514   # └
$H = [string][char]0x2500   # ─
$tee  = $T + $H + $H + ' '
$elbo = $L + $H + $H + ' '
$pipe = $V + '   '

# ---- tree ----
$tree = New-Object System.Text.StringBuilder
function Write-Tree($dir, $prefix) {
  $items = @(Get-ChildItem $dir -Force | Where-Object {
    $fileSet.Contains($_.FullName) -or ($_.PSIsContainer -and $dirSet.Contains($_.FullName))
  } | Sort-Object @{e={-not $_.PSIsContainer}}, Name)
  for ($i = 0; $i -lt $items.Count; $i++) {
    $it   = $items[$i]
    $last = ($i -eq $items.Count - 1)
    $branch = if ($last) { $elbo } else { $tee }
    $name   = if ($it.PSIsContainer) { $it.Name + '/' } else { $it.Name }
    [void]$tree.AppendLine($prefix + $branch + $name)
    if ($it.PSIsContainer) {
       $next = if ($last) { '    ' } else { $pipe }
      Write-Tree $it.FullName ($prefix + $next)
    }
  }
}
[void]$tree.AppendLine((Split-Path $root -Leaf) + '/')
Write-Tree $root ''

# ---- build markdown ----
$sb = New-Object System.Text.StringBuilder
[void]$sb.AppendLine('# Project dump')
[void]$sb.AppendLine('')
[void]$sb.AppendLine('Excluded: node_modules, .astro, dist, .git, public/fonts, package-lock.json, binaries.')
[void]$sb.AppendLine('')
[void]$sb.AppendLine('## File tree')
[void]$sb.AppendLine('')
[void]$sb.AppendLine('```text')
[void]$sb.Append($tree.ToString())
[void]$sb.AppendLine('```')
[void]$sb.AppendLine('')
[void]$sb.AppendLine('## Files')

foreach ($f in $files) {
  $rel  = $f.FullName.Substring($root.Length + 1).Replace('\','/')
  $ext  = $f.Extension.ToLower()
  $code = [IO.File]::ReadAllText($f.FullName).TrimEnd()
  $run  = 0
  foreach ($m in [regex]::Matches($code, '`+')) { if ($m.Length -gt $run) { $run = $m.Length } }
  $fence = '`' * [Math]::Max(3, $run + 1)

  [void]$sb.AppendLine('')
  [void]$sb.AppendLine("### $($f.Name) @ $rel")
  [void]$sb.AppendLine('')
  [void]$sb.AppendLine($fence + $lang[$ext])
  [void]$sb.AppendLine($code)
  [void]$sb.AppendLine($fence)
}

[IO.File]::WriteAllText($out, $sb.ToString(), (New-Object Text.UTF8Encoding $false))
$kb = '{0:N0}' -f ((Get-Item $out).Length / 1KB)
Write-Host "Done: $out ($($files.Count) files, $kb KB)"